# import logging
from logging import *

# print(logging.NOTSET)
# print(logging.DEBUG)
# print(logging.INFO)
# print(logging.WARNING)
# print(logging.ERROR)
# print(logging.CRITICAL)

basicConfig(level=logging.DEBUG)
info('hello python')
