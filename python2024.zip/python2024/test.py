def add_greet_method(cls):
    cls.greet = lambda self: print(f"Hello from {self.__class__.__name__}")
    return cls

@add_greet_method
class Person:
    def __init__(self, name):
        self.name = name

# 使用示例
p = Person("Alice")
p.greet()  # 輸出: Hello from Person
